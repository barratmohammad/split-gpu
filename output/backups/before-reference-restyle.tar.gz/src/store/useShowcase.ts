import { create } from 'zustand';
import type { Level } from '../data/types';

export const DIE_PART_ID = 'gpu-die';
export const INITIAL_EXPLODE = 0;

export interface ShowcaseState {
  /** Slider target, 0 = assembled, 1 = fully exploded. Parts ease toward it. */
  explode: number;
  level: Level;
  selectedId: string | null;
  hoveredId: string | null;
  /** True while the camera and assemblies animate between levels. */
  transitioning: boolean;
  /** Bumped to ask the camera rig to return to its default framing. */
  resetToken: number;
  /** Which GPC hosts the SM bank that was last hovered or selected. */
  smHostId: string | null;

  setExplode: (v: number) => void;
  select: (id: string | null) => void;
  selectSm: (hostId: string) => void;
  hover: (id: string | null) => void;
  enterDie: () => void;
  backToModule: () => void;
  endTransition: () => void;
  resetView: () => void;
}

export const useShowcase = create<ShowcaseState>((set) => ({
  explode: INITIAL_EXPLODE,
  level: 'module',
  selectedId: null,
  hoveredId: null,
  transitioning: false,
  resetToken: 0,
  smHostId: null,

  setExplode: (v) => set({ explode: Math.min(1, Math.max(0, v)) }),
  select: (id) => set({ selectedId: id }),
  selectSm: (hostId) => set({ selectedId: 'sm', smHostId: hostId }),
  hover: (id) => set({ hoveredId: id }),
  enterDie: () =>
    set({ level: 'die', selectedId: null, hoveredId: null, transitioning: true, explode: INITIAL_EXPLODE }),
  backToModule: () =>
    set({ level: 'module', selectedId: null, hoveredId: null, transitioning: true, explode: INITIAL_EXPLODE }),
  endTransition: () => set({ transitioning: false }),
  resetView: (): void =>
    set((s) => ({
      selectedId: null,
      hoveredId: null,
      explode: INITIAL_EXPLODE,
      resetToken: s.resetToken + 1,
    })),
}));
