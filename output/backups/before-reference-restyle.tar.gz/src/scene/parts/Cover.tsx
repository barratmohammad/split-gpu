import { RoundedBox } from '@react-three/drei';
import type { Vec3 } from '../../data/types';
import { getMaterial } from '../materials';

interface Props {
  size: Vec3;
}

/** The small plastic cap lifted off the heatsink in step one of the service procedure. */
export function Cover({ size }: Props) {
  return <RoundedBox args={size} radius={0.03} smoothness={3} material={getMaterial('plasticCover')} castShadow receiveShadow />;
}
