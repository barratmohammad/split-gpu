import { RoundedBox } from '@react-three/drei';
import type { MaterialKind, Vec3 } from '../../data/types';
import { getMaterial } from '../materials';

/** Chamfered molded package with subtle top tooling and visible terminations. */
export function BoardComponent({ size: [w, h, d], material }: { size: Vec3; material: MaterialKind }) {
  return <group>
    <RoundedBox args={[w, h, d]} radius={0.025} smoothness={2} material={getMaterial(material)} castShadow receiveShadow />
    <mesh position={[0, h / 2 + 0.002, 0]}>
      <boxGeometry args={[w * 0.72, 0.004, d * 0.68]} />
      <meshStandardMaterial color={material === 'graphite' ? '#646a68' : '#303733'} roughness={0.8} metalness={0.12} />
    </mesh>
    {[-1, 1].map(side => <mesh key={side} position={[side * (w / 2 - .015), -h / 2 + .025, 0]} material={getMaterial('silverMetal')}>
      <boxGeometry args={[.04, .04, d * .66]} />
    </mesh>)}
  </group>;
}
