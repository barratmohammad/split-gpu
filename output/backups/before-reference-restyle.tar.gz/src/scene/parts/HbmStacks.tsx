import { useMemo } from 'react';
import type { Vec3 } from '../../data/types';
import { Instances } from './Instances';

interface Props {
  size: Vec3;
  positions: Vec3[];
}

/** Six memory positions drawn identically: none is marked active or inactive. */
export function HbmStacks({ size: [w, h, d], positions }: Props) {
  const lids = useMemo<Vec3[]>(() => positions.map((p): Vec3 => [p[0], h / 2 - 0.01, p[2]]), [positions, h]);
  return (
    <group>
      <Instances positions={positions} size={[w, h, d]} material="siliconGray" />
      <Instances positions={lids} size={[w * 0.9, 0.02, d * 0.9]} material="blackPlastic" />
    </group>
  );
}
