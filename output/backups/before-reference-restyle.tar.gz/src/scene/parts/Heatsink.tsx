import { RoundedBox } from '@react-three/drei';
import type { Vec3 } from '../../data/types';
import { getMaterial } from '../materials';

interface Props {
  size: Vec3;
}

/**
 * The GPU/heatsink assembly as the service drawings show it: one tall block.
 * Neutral finish; shallow grooves suggest panels without claiming fin geometry.
 */
export function Heatsink({ size: [w, h, d] }: Props) {
  const grooves = [-0.3, 0.05, 0.4].map((f) => f * d);
  return (
    <group>
      <RoundedBox args={[w, h, d]} radius={0.08} smoothness={3} material={getMaterial('neutralGray')} castShadow receiveShadow />
      {grooves.map((z, i) => (
        <mesh key={i} position={[0, h / 2 + 0.001, z]} material={getMaterial('graphite')}>
          <boxGeometry args={[w * 0.9, 0.012, 0.05]} />
        </mesh>
      ))}
      <mesh position={[0.6, h / 2 - 0.02, 0]} material={getMaterial('graphite')}>
        <boxGeometry args={[2.7, 0.05, 1.5]} />
      </mesh>
    </group>
  );
}
