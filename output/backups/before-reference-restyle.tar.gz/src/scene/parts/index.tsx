import { BoardComponent } from './BoardComponent';
import { getMaterial } from '../materials';
import type { PartDef } from '../../data/types';
import { Board } from './Board';
import { PowerFlanks } from './PowerFlanks';
import { Package } from './Package';
import { HbmStacks } from './HbmStacks';
import { GpuDie } from './GpuDie';
import { Heatsink } from './Heatsink';
import { Cover } from './Cover';
import { DieBase } from './DieBase';
import { Region } from './Region';

/** Picks the geometry builder for a part definition. */
export function PartGeometry({ def }: { def: PartDef }) {
  const g = def.geometry;
  switch (g.kind) {
    case 'fastener':
      return <group>
        <mesh material={getMaterial(g.material)} castShadow>
          <cylinderGeometry args={[g.size[0] * 0.28, g.size[0] * 0.28, g.size[1], 12]} />
        </mesh>
        <mesh position={[0, g.size[1] * 0.4, 0]} material={getMaterial(g.material)} castShadow>
          <cylinderGeometry args={[g.size[0] / 2, g.size[0] / 2, g.size[1] * 0.2, 6]} />
        </mesh>
      </group>;
    case 'component':
      return <BoardComponent size={g.size} material={g.material} />;
    case 'board':
      return <Board {...g} />;
    case 'powerFlanks':
      return <PowerFlanks {...g} />;
    case 'package':
      return <Package {...g} />;
    case 'hbm':
      return <HbmStacks {...g} />;
    case 'die':
      return <GpuDie {...g} />;
    case 'heatsink':
      return <Heatsink {...g} />;
    case 'cover':
      return <Cover {...g} />;
    case 'dieBase':
      return <DieBase {...g} />;
    case 'region':
      return <Region {...g} partId={def.id} />;
    case 'virtual':
      return null;
  }
}
