import { Environment as DreiEnvironment, Lightformer } from '@react-three/drei';

/** Studio illumination without a reflective plane or contact-shadow rectangle. */
export function Environment() {
  return <>
    <ambientLight intensity={0.55} />
    <directionalLight position={[3, 10, 5]} intensity={2.2} castShadow
      shadow-mapSize={[2048, 2048]} shadow-bias={-0.0002}
      shadow-camera-left={-22} shadow-camera-right={22} shadow-camera-top={20}
      shadow-camera-bottom={-20} shadow-camera-far={60} />
    <directionalLight position={[-6, 3, -5]} intensity={1.1} color="#e2e8f1" />
    <DreiEnvironment resolution={256} frames={1} environmentIntensity={0.7}>
      <color attach="background" args={['#697480']} />
      <Lightformer intensity={2} position={[0, 7, 3]} rotation-x={Math.PI / 2} scale={[12, 4, 1]} />
      <Lightformer intensity={3} position={[-6, 3, 2]} rotation-y={Math.PI / 2} scale={[5, 3, 1]} />
      <Lightformer intensity={1.8} position={[7, 3, -5]} rotation-y={-Math.PI / 2} scale={[6, 3, 1]} />
    </DreiEnvironment>
    <mesh rotation-x={-Math.PI / 2} position={[0, -0.45, 0]} receiveShadow>
      <planeGeometry args={[200, 200]} />
      <shadowMaterial transparent opacity={0.13} />
    </mesh>
  </>;
}
