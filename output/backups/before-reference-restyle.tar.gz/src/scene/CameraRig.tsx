import { useEffect, useRef } from 'react';
import { CameraControls } from '@react-three/drei';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import type CameraControlsImpl from 'camera-controls';
import { getPart } from '../data';
import type { Level } from '../data/types';
import { levelBox, partTargetBox, type LocalBox } from '../lib/framing';
import { useShowcase } from '../store/useShowcase';
import { partRefs } from './partRefs';

/** Default viewing direction per level (unit vector from subject toward camera). */
const VIEW_DIR: Record<Level, THREE.Vector3> = {
  module: new THREE.Vector3(0.42, 1.5, 1.8).normalize(),
  die: new THREE.Vector3(0.02, 1.2, 0.65).normalize(),
};

/** How far left of center the subject sits so it stays clear of the info panel. */
const PANEL_SHIFT = 0;

const UP = new THREE.Vector3(0, 1, 0);
const tmpBox = new THREE.Box3();

function toLocalBox(b: THREE.Box3): LocalBox {
  return { min: [b.min.x, b.min.y, b.min.z], max: [b.max.x, b.max.y, b.max.z] };
}

/**
 * Moves the camera so a box fits the view along `dir`, shifted left on wide
 * screens. Uses the box's bounding sphere, which is simple and never clips.
 */
function frameBox(
  controls: CameraControlsImpl,
  camera: THREE.PerspectiveCamera,
  box: LocalBox,
  dir: THREE.Vector3,
  animate: boolean,
  fill = 1.1,
  minDistance = 3,
) {
  const center = new THREE.Vector3(
    (box.min[0] + box.max[0]) / 2,
    (box.min[1] + box.max[1]) / 2,
    (box.min[2] + box.max[2]) / 2,
  );
  const vfov = (camera.fov * Math.PI) / 180;
  const forward = dir.clone().negate();
  const right = new THREE.Vector3().crossVectors(forward, UP).normalize();
  const screenUp = new THREE.Vector3().crossVectors(dir, right).normalize();
  const wide = camera.aspect > 1.1;
  const tanV = Math.tan(vfov / 2) * 0.82;
  const tanH = Math.tan(vfov / 2) * camera.aspect * 0.9;
  let distance = minDistance;
  for (const x of [box.min[0], box.max[0]]) {
    for (const y of [box.min[1], box.max[1]]) {
      for (const z of [box.min[2], box.max[2]]) {
        const corner = new THREE.Vector3(x, y, z).sub(center);
        const depth = corner.dot(dir);
        distance = Math.max(distance, depth + Math.abs(corner.dot(right)) / tanH * fill,
          depth + Math.abs(corner.dot(screenUp)) / tanV * fill);
      }
    }
  }
  const halfWidth = distance * Math.tan(vfov / 2) * camera.aspect;
  const shift = wide ? halfWidth * PANEL_SHIFT : 0;
  const target = center.clone().addScaledVector(right, shift);
  const position = target.clone().addScaledVector(dir, distance);
  void controls.setLookAt(position.x, position.y, position.z, target.x, target.y, target.z, animate);
}

/** Owns the camera: default framing, glide to a selected part, reset, and level changes. */
export function CameraRig() {
  const ref = useRef<CameraControlsImpl>(null!);
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera;
  const explode = useShowcase((s) => s.explode);
  const viewport = useThree((s) => s.size);
  const level = useShowcase((s) => s.level);
  const selectedId = useShowcase((s) => s.selectedId);
  const resetToken = useShowcase((s) => s.resetToken);
  const first = useRef(true);

  const frameLevel = (animate: boolean) => {
    const { level: lvl, explode } = useShowcase.getState();
    frameBox(ref.current, camera, levelBox(lvl, explode), VIEW_DIR[lvl], animate, 1.02);
  };

  const currentDir = () => {
    const target = new THREE.Vector3();
    ref.current.getTarget(target);
    const dir = camera.position.clone().sub(target);
    return dir.lengthSq() < 1e-6 ? VIEW_DIR[level].clone() : dir.normalize();
  };

  useEffect(() => {
    frameLevel(!first.current);
    first.current = false;
    const t = window.setTimeout(() => useShowcase.getState().endTransition(), 900);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [level]);

  useEffect(() => {
    frameLevel(true);
    // Refit after horizontal separation and viewport resize.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [explode, viewport.width, viewport.height]);

  useEffect(() => {
    if (resetToken === 0) return;
    frameLevel(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetToken]);

  useEffect(() => {
    if (!selectedId) return;
    const def = getPart(selectedId);
    if (!def) return;
    if (def.geometry.kind === 'virtual') {
      const t = window.setTimeout(() => {
        const obj = partRefs.get(selectedId);
        if (!obj) return;
        tmpBox.setFromObject(obj);
        frameBox(ref.current, camera, toLocalBox(tmpBox), currentDir(), true, 1.4, 5);
      }, 350);
      return () => window.clearTimeout(t);
    }
    const box = partTargetBox(def, useShowcase.getState().explode);
    const minDist = useShowcase.getState().level === 'module' ? 9 : 6;
    const t = window.setTimeout(() => frameBox(ref.current, camera, box, currentDir(), true, 1.6, minDist), 80);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  return (
    <CameraControls
      ref={ref}
      makeDefault
      smoothTime={0.55}
      draggingSmoothTime={0.12}
      minDistance={3}
      maxDistance={200}
      maxPolarAngle={Math.PI / 2 - 0.04}
      dollyToCursor={false}
    />
  );
}
