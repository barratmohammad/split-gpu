import type { GeometryDef, Level, PartDef, Vec3 } from '../data/types';
import { partsForLevel } from '../data';
import { CONTROLLER_OFFSETS } from '../data/dieParts';
import { partPosition } from './explode';

export interface LocalBox {
  min: Vec3;
  max: Vec3;
}

function boxFromPoints(points: Vec3[], size: Vec3): LocalBox {
  const min: Vec3 = [Infinity, Infinity, Infinity];
  const max: Vec3 = [-Infinity, -Infinity, -Infinity];
  for (const p of points) {
    for (let i = 0; i < 3; i++) {
      min[i] = Math.min(min[i], p[i] - size[i] / 2);
      max[i] = Math.max(max[i], p[i] + size[i] / 2);
    }
  }
  return { min, max };
}

function centered(size: Vec3): LocalBox {
  return { min: [-size[0] / 2, -size[1] / 2, -size[2] / 2], max: [size[0] / 2, size[1] / 2, size[2] / 2] };
}

/** Axis-aligned bounds of a part's geometry relative to the part group origin. */
export function partLocalBox(geometry: GeometryDef): LocalBox {
  switch (geometry.kind) {
    case 'fastener':
    case 'component':
    case 'board':
    case 'package':
    case 'die':
    case 'heatsink':
    case 'cover':
    case 'dieBase':
      return centered(geometry.size);
    case 'powerFlanks': {
      const [w, , d] = geometry.boardSize;
      return { min: [-w / 2 + 0.2, 0, -d / 2 + 0.2], max: [w / 2 - 0.2, 0.6, d / 2 - 0.2] };
    }
    case 'hbm':
      return boxFromPoints(geometry.positions, geometry.size);
    case 'region':
      return geometry.style === 'controller' && !geometry.single
        ? boxFromPoints(CONTROLLER_OFFSETS, geometry.size)
        : centered(geometry.size);
    case 'virtual':
      return { min: [0, 0, 0], max: [0, 0, 0] };
  }
}

/** World-space bounds of a part when it has settled at a given explode amount. */
export function partTargetBox(def: PartDef, explode: number): LocalBox {
  const p = partPosition(def.basePosition, def.explodeVector, explode);
  const local = partLocalBox(def.geometry);
  return {
    min: [p[0] + local.min[0], p[1] + local.min[1], p[2] + local.min[2]],
    max: [p[0] + local.max[0], p[1] + local.max[1], p[2] + local.max[2]],
  };
}

/** Union of every rendered part's settled bounds on a level. */
export function levelBox(level: Level, explode: number): LocalBox {
  const min: Vec3 = [Infinity, Infinity, Infinity];
  const max: Vec3 = [-Infinity, -Infinity, -Infinity];
  for (const def of partsForLevel(level)) {
    if (def.geometry.kind === 'virtual') continue;
    const b = partTargetBox(def, explode);
    for (let i = 0; i < 3; i++) {
      min[i] = Math.min(min[i], b.min[i]);
      max[i] = Math.max(max[i], b.max[i]);
    }
  }
  return { min, max };
}

/** Where the floating label should attach: top-right edge of the part, in world space. */
export function labelAnchor(def: PartDef, explode: number): Vec3 {
  const b = partTargetBox(def, explode);
  return [b.max[0] * 0.55 + b.min[0] * 0.45, b.max[1] + 0.08, (b.min[2] + b.max[2]) / 2];
}
