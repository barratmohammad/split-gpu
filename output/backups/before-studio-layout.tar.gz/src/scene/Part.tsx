import { useEffect, useRef, type ReactNode } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import { useCursor } from '@react-three/drei';
import type * as THREE from 'three';
import type { PartDef, Vec3 } from '../data/types';
import { damp, partPosition } from '../lib/explode';
import { useShowcase } from '../store/useShowcase';
import { partRefs } from './partRefs';
import { useOutline } from './useOutline';

interface Props {
  def: PartDef;
  children: ReactNode;
}

/**
 * A clickable, hoverable group that eases toward its exploded position every
 * frame. Geometry builders are passed as children.
 */
export function Part({ def, children }: Props) {
  const ref = useRef<THREE.Group>(null!);
  const target = useRef<Vec3>([...def.basePosition]);
  const selectedId = useShowcase((s) => s.selectedId);
  const hoveredId = useShowcase((s) => s.hoveredId);
  const isSelected = selectedId === def.id;
  const isHovered = hoveredId === def.id;

  useEffect(() => {
    partRefs.set(def.id, ref.current);
    return () => {
      partRefs.delete(def.id);
    };
  }, [def.id]);

  useFrame((_, dt) => {
    const t = partPosition(def.basePosition, def.explodeVector, useShowcase.getState().explode, target.current);
    const p = ref.current.position;
    const k = Math.min(dt, 0.1);
    p.x = damp(p.x, t[0], 7, k);
    p.y = damp(p.y, t[1], 7, k);
    p.z = damp(p.z, t[2], 7, k);
  });

  useCursor(isHovered);
  useOutline(ref, isSelected || isHovered);

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    useShowcase.getState().select(def.id);
  };
  const onDoubleClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    if (def.drillInto === 'die') useShowcase.getState().enterDie();
  };
  const onPointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    useShowcase.getState().hover(def.id);
  };
  const onPointerOut = () => {
    if (useShowcase.getState().hoveredId === def.id) useShowcase.getState().hover(null);
  };

  return (
    <group
      ref={ref}
      position={def.basePosition}
      onClick={onClick}
      onDoubleClick={onDoubleClick}
      onPointerOver={onPointerOver}
      onPointerOut={onPointerOut}
    >
      {children}
    </group>
  );
}
