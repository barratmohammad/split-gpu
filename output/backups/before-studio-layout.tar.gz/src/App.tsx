import { Scene } from './scene/Scene';
import { Breadcrumb } from './ui/Breadcrumb';
import { DieNotes } from './ui/DieNotes';
import { ExplodeSlider } from './ui/ExplodeSlider';
import { InfoPanel } from './ui/InfoPanel';
import { TopBar } from './ui/TopBar';

export default function App() {
  return (
    <div className="app">
      <Scene />
      <TopBar />
      <InfoPanel />
      <DieNotes />
      <div className="bottombar">
        <Breadcrumb />
        <ExplodeSlider />
      </div>
    </div>
  );
}
